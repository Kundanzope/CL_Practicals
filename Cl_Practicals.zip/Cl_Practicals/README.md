# cl-pratical
 how to execute pratical no 11 in vscode
 💡 How to Run in VS Code

1. **Install Pyro4** (if not already):
   
   pip install Pyro4
   

2. **Run the Server** in a new terminal:
   
   python hotel_booking_server.py
   

4. **Run the Client** in another terminal:
  
   python hotel_booking_client.py
  

Now you can interact with the hotel booking system via terminal inputs (BOOK, CANCEL, EXIT). Make sure all files are in the same folder.
