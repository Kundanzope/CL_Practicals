import Pyro4

def main():
    server = Pyro4.Proxy("PYRONAME:string.concat")  # Connect using registered name
    str1 = input("Enter first string: ")
    str2 = input("Enter second string: ")

    result = server.concatenate_strings(str1, str2)
    print("Concatenated Result:", result)

if __name__ == "__main__":
    main()
