
import Pyro4

@Pyro4.expose
class StringConcatenationServer:
    def concatenate_strings(self, str1, str2):
        return str1 + str2

def main():
    daemon = Pyro4.Daemon()  # Create Pyro daemon
    ns = Pyro4.locateNS()    # Locate the name server

    server = StringConcatenationServer()
    uri = daemon.register(server)
    ns.register("string.concat", uri)

    print("Server is ready. URI:", uri)
    daemon.requestLoop()

if __name__ == "__main__":
    main()
